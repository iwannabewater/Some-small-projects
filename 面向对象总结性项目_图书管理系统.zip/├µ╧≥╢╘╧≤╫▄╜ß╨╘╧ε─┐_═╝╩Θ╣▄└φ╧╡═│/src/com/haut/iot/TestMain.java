package com.haut.iot;

import com.haut.iot.book.BookList;
import com.haut.iot.user.Admin;
import com.haut.iot.user.NormalUser;
import com.haut.iot.user.User;

import java.util.Scanner;

public class TestMain {
    public static void main(String[] args) {
        //1.准备书籍
        BookList bookList = new BookList();
        //2.登录
        User user = login();//向上转型

        //主循环
        while (true) {
            int choice = user.showMenu();
            //选择是几，就可以对应哪个方法
            user.doOperation(bookList, choice);//动态绑定
        }
    }

    public static User login() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please input your name :>");
        String name = scanner.nextLine();
        System.out.println("Please enter your identity(1.Admin 2.NormalUser) :>");
        int choice = scanner.nextInt();


        if (choice == 1) { //选择是1，则为管理员，反之则为普通用户
            return new Admin(name);
        } else {
            return new NormalUser(name);
        }



    }
}




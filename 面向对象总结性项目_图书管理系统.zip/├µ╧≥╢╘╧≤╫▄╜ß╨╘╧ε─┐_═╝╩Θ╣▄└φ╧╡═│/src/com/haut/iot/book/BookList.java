package com.haut.iot.book;

public class BookList {
    private Book[] books = new Book[100]; //books数组存储书籍
    private int usedSize = 0; //已经使用过的大小

    //设置几个初始值, 方便后续测试.
    public BookList() {
        books[0] = new Book("三国演义", "罗贯中", 50, "小说");
        books[1] = new Book("水浒传", "施耐庵", 88, "小说");
        books[2] = new Book("西游记", "吴承恩", 100, "小说");
        this.usedSize = 3; //将useSize置为3
    }

    public Book getBook(int pos) { //get book
        return this.books[pos];
    }
    //尾插图书
    public void setBook(int pos, Book book) { //set book
        books[pos] = book;
    }

    public int getUsedSize() { //get usedSize
        return usedSize;
    }

    public void setUsedSize(int usedSize) { // set usedSize
        this.usedSize = usedSize;
    }

}

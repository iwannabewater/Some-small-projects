package com.haut.iot.operation;

import com.haut.iot.book.Book;
import com.haut.iot.book.BookList;

import java.util.Scanner;

public class AddOperation implements IOperation {
    @Override
    public void work(BookList bookList) {
        System.out.println("新增图书");
        Scanner scanner = new Scanner(System.in);//扫描器
        //输入书名
        System.out.println("Please enter the name of the book :>");
        String name = scanner.nextLine();
        //输入作者
        System.out.println("Please enter author of book :>");
        String author = scanner.nextLine();
        //输入价格
        System.out.println("Please enter the price of the book :>");
        double price = scanner.nextDouble();
        //输入类型
        System.out.println("Please enter the type of book :>");
        String type = scanner.next(); //这里用next避免nextDouble带来的影响

        Book book = new Book(name, author, price, type);

        int curSize = bookList.getUsedSize();//获取当前已存放大小
        bookList.setBook(curSize, book);

        bookList.setUsedSize(curSize + 1);//usedSize + 1
        System.out.println("Added books successfully~");
    }


}

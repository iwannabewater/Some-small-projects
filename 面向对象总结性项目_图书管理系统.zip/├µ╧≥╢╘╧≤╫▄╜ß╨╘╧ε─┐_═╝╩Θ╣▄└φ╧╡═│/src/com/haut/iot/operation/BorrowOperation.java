package com.haut.iot.operation;

import com.haut.iot.book.Book;
import com.haut.iot.book.BookList;

import java.util.Scanner;


public class BorrowOperation implements IOperation {
    @Override
    public void work(BookList bookList) {
        System.out.println("借阅图书");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the name of the book :>");

        String name = scanner.nextLine();

        for (int i = 0; i < bookList.getUsedSize(); i++) {

            Book book = bookList.getBook(i);
            if (book.getBookName().equals(name)) {
                //可以借阅
                book.setBorrowed(true);
                System.out.println("Borrowing successful~");
                return;
            }
        }
        System.out.println("There is no such book as you want to borrow~");

    }
}

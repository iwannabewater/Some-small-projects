package com.haut.iot.operation;

import com.haut.iot.book.Book;
import com.haut.iot.book.BookList;

import java.util.Scanner;

public class DeleteOperation implements IOperation {
    @Override
    public void work(BookList bookList) {
        System.out.println("删除图书");
        Scanner scanner = new Scanner(System.in);

        System.out.println("Please enter the name of the book :>");
        String name = scanner.nextLine();
        int i = 0;//从0开始遍历
        for (i = 0; i < bookList.getUsedSize(); i++) {

            Book book = bookList.getBook(i);
            if (book.getBookName().equals(name)) {
                //可以删除
                break;
            }
        }
        if (i == bookList.getUsedSize()) {
            System.out.println("There are no books you want to delete~");
            return;
        }

        //删除 ==>类比顺序表
        for (int pos = i; pos < bookList.getUsedSize() - 1; pos++) {
            Book book = bookList.getBook(pos + 1);
            bookList.setBook(pos, book); //下一个元素覆盖上一个元素
        }
        System.out.println("Delete successful~");
        bookList.setUsedSize(bookList.getUsedSize() - 1);//有效个数减一


    }
}

package com.haut.iot.operation;

import com.haut.iot.book.Book;
import com.haut.iot.book.BookList;

import java.util.Scanner;

public class FindOperation implements IOperation {
    @Override
    public void work(BookList bookList) {
        System.out.println("查找图书");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the name of the book :>");

        String name = scanner.nextLine();

        for (int i = 0; i < bookList.getUsedSize(); i++) {

            Book book = bookList.getBook(i);
            if (book.getBookName().equals(name)) {
                //可以查找
                System.out.println(book);
                System.out.println("Finding successful~");
                return;
            }
        }
        System.out.println("There is no such book as you are looking for~");

    }
}

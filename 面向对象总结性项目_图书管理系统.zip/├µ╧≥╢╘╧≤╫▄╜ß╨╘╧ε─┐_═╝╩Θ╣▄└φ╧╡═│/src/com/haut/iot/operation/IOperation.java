package com.haut.iot.operation;

import com.haut.iot.book.BookList; //导包

public interface IOperation { //接口
    void work(BookList bookList);//抽象方法
}

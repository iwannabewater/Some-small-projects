package com.haut.iot.operation;

import com.haut.iot.book.Book;
import com.haut.iot.book.BookList;
import javafx.scene.transform.Scale;

import java.util.Scanner;

public class ReturnOperation implements IOperation {
    @Override
    public void work(BookList bookList) {
        System.out.println("归还图书");
        Scanner scanner = new Scanner(System.in);

        System.out.println("Please enter the name of the book :>");
        String name = scanner.nextLine();
        for (int i = 0; i < bookList.getUsedSize(); i++) {

            Book book = bookList.getBook(i);
            if (book.getBookName().equals(name)) {
                //可以归还
                book.setBorrowed(false);
                System.out.println("Return successful~");
                return;
            }
        }
        System.out.println("There is no book you want to return~");


    }
}

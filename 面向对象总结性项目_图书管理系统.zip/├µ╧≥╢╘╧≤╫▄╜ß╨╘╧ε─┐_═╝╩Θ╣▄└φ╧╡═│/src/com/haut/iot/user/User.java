package com.haut.iot.user;

import com.haut.iot.book.BookList;
import com.haut.iot.operation.IOperation;

// User类是一个抽象类, 每个子类需要做两件事情
// 1. 初始化对应的操作数组
// 2. 实现 Menu 菜单
public abstract class User {
    protected String name; //姓名
    protected IOperation[] operations; //操作数组

    public User(String name) {
        this.name = name;
    }

    public abstract int showMenu();

    public void doOperation(BookList bookList, int choice) {
        //选择执行哪个操作
        this.operations[choice].work(bookList);
    }
}

